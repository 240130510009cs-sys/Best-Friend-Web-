<?php
declare(strict_types=1);

/* =====================================================
   ERROR REPORTING (turn off in production)
===================================================== */
error_reporting(E_ALL);
ini_set('display_errors', '1');

/* =====================================================
   DATABASE CONFIG
===================================================== */
$DB_HOST = 'localhost';
$DB_NAME = 'our_little_quiz';
$DB_USER = 'root';
$DB_PASS = '';

$dbError = null;
$pdo = null;

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );

    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$DB_NAME`
                CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");

    $pdo->exec("USE `$DB_NAME`");

    $pdo->exec("
        CREATE TABLE IF NOT EXISTS quiz_answers (
            id INT AUTO_INCREMENT PRIMARY KEY,
            food_category VARCHAR(100),
            food_dish VARCHAR(150),
            roti_type VARCHAR(100),
            street_food VARCHAR(150),
            homemade_food VARCHAR(150),
            custom_food TEXT,
            icecream_company VARCHAR(100),
            icecream_flavor VARCHAR(100),
            comfortable VARCHAR(100),
            meeting_activities TEXT,
            movie_category VARCHAR(100),
            garden_location VARCHAR(100),
            mall_choice VARCHAR(100),
            sport_choice VARCHAR(100),
            meeting_date DATE NULL,
            meeting_time TIME NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");

} catch (Throwable $e) {
    $dbError = $e->getMessage();
}


/* =====================================================
   POST — SAVE QUIZ
===================================================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_quiz'])) {
    header('Content-Type: application/json; charset=utf-8');

    if ($dbError) {
        echo json_encode(['success' => false, 'message' => 'DB error: ' . $dbError]);
        exit;
    }

    try {
        $foodCategory      = trim($_POST['food_category'] ?? '');
        $foodDish          = trim($_POST['food_dish'] ?? '');
        $rotiType          = trim($_POST['roti_type'] ?? '');
        $streetFood        = trim($_POST['street_food'] ?? '');
        $homemadeFood      = trim($_POST['homemade_food'] ?? '');
        $customFood        = trim($_POST['custom_food'] ?? '');
        $icecreamCompany   = trim($_POST['icecream_company'] ?? '');
        $icecreamFlavor    = trim($_POST['icecream_flavor'] ?? '');
        $comfortable       = trim($_POST['comfortable'] ?? '');
        $meetingActivities = trim($_POST['meeting_activities'] ?? '');
        $movieCategory     = trim($_POST['movie_category'] ?? '');
        $gardenLocation    = trim($_POST['garden_location'] ?? '');
        $mallChoice        = trim($_POST['mall_choice'] ?? '');
        $sportChoice       = trim($_POST['sport_choice'] ?? '');
        $meetingDate       = trim($_POST['meeting_date'] ?? '');
        $meetingTime       = trim($_POST['meeting_time'] ?? '');

        $meetingDateVal = $meetingDate !== '' ? $meetingDate : null;
        $meetingTimeVal = $meetingTime !== '' ? $meetingTime . ':00' : null;

        $stmt = $pdo->prepare("
            INSERT INTO quiz_answers (
                food_category, food_dish, roti_type,
                street_food, homemade_food, custom_food,
                icecream_company, icecream_flavor, comfortable,
                meeting_activities, movie_category, garden_location,
                mall_choice, sport_choice, meeting_date, meeting_time
            ) VALUES (
                :food_category, :food_dish, :roti_type,
                :street_food, :homemade_food, :custom_food,
                :icecream_company, :icecream_flavor, :comfortable,
                :meeting_activities, :movie_category, :garden_location,
                :mall_choice, :sport_choice, :meeting_date, :meeting_time
            )
        ");

        $stmt->execute([
            ':food_category'      => $foodCategory,
            ':food_dish'          => $foodDish,
            ':roti_type'          => $rotiType,
            ':street_food'        => $streetFood,
            ':homemade_food'      => $homemadeFood,
            ':custom_food'        => $customFood,
            ':icecream_company'   => $icecreamCompany,
            ':icecream_flavor'    => $icecreamFlavor,
            ':comfortable'        => $comfortable,
            ':meeting_activities' => $meetingActivities,
            ':movie_category'     => $movieCategory,
            ':garden_location'    => $gardenLocation,
            ':mall_choice'        => $mallChoice,
            ':sport_choice'       => $sportChoice,
            ':meeting_date'       => $meetingDateVal,
            ':meeting_time'       => $meetingTimeVal,
        ]);

        echo json_encode([
            'success' => true,
            'message' => 'Quiz saved successfully 💛',
            'id'      => (int)$pdo->lastInsertId(),
        ]);

    } catch (Throwable $e) {
        echo json_encode(['success' => false, 'message' => $e->getMessage()]);
    }
    exit;
}


/* =====================================================
   VIEW ANSWERS
===================================================== */
if (isset($_GET['view_answers'])) {
    if ($dbError) die('DB error: ' . htmlspecialchars($dbError));
    $rows = $pdo->query("SELECT * FROM quiz_answers ORDER BY id DESC")->fetchAll();
    ?>
    <!DOCTYPE html>
    <html>
    <head>
        <meta charset="UTF-8">
        <title>Quiz Answers</title>
        <style>
            body{font-family:Arial;background:#2c1f26;color:#f5e6e8;padding:30px}
            h1{color:#d4a5b0}
            .wrap{overflow-x:auto;background:rgba(255,245,246,.06);border:1px solid rgba(212,165,176,.4);border-radius:16px;padding:20px}
            table{width:100%;border-collapse:collapse;min-width:1200px;color:#e8d5d9}
            th,td{padding:10px;border-bottom:1px solid rgba(212,165,176,.2);text-align:left;font-size:13px}
            th{background:rgba(212,165,176,.15);color:#d4a5b0;text-transform:uppercase;font-size:11px}
            tr:hover{background:rgba(212,165,176,.06)}
            .empty{color:#a88b93;text-align:center;padding:40px}
        </style>
    </head>
    <body>
    <h1>💛 Quiz Answers</h1>
    <div class="wrap">
        <?php if (empty($rows)): ?>
            <div class="empty">No submissions yet.</div>
        <?php else: ?>
        <table>
            <thead>
            <tr>
                <?php foreach (array_keys($rows[0]) as $c): ?>
                    <th><?= htmlspecialchars($c) ?></th>
                <?php endforeach; ?>
            </tr>
            </thead>
            <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <?php foreach ($r as $v): ?>
                        <td><?= htmlspecialchars((string)$v) ?></td>
                    <?php endforeach; ?>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php endif; ?>
    </div>
    </body>
    </html>
    <?php
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Your Nick's Quize 💛</title>
<style>
*{box-sizing:border-box;margin:0;padding:0}
html{scroll-behavior:smooth}

/* =====================================================
   🎨 OPTIMIZED PALETTE
===================================================== */
:root{
  --dusty-rose:     #d4a5b0;
  --cream-white:    #faf3f0;
  --deep-mauve:     #2c1f26;

  --rose-light:     #ecd0d6;
  --rose-soft:      #e0bcc4;
  --rose-mid:       #d4a5b0;
  --rose-deep:      #b8838f;
  --rose-shadow:    #8a5c67;

  --cream:          #faf3f0;
  --cream-soft:     #f5e6e8;
  --cream-dim:      #e8d5d9;

  --mauve:          #2c1f26;
  --mauve-soft:     #3d2b33;
  --mauve-light:    #4f3840;
  --mauve-deep:     #1a1216;

  --bg-card:        #2c1f26;
  --bg-elevated:    #3d2b33;
  --text-main:      #faf3f0;
  --text-dim:       #b8a0a8;
  --text-accent:    #d4a5b0;
  --border-glow:    rgba(212, 165, 176, 0.35);
  --border-soft:    rgba(212, 165, 176, 0.18);
}

body{
  min-height:100vh;
  font-family:'Segoe UI','Inter',Arial,sans-serif;
  color:var(--text-main);
  overflow-x:hidden;
  /* Simplified single gradient — much faster than multi-radial + animation */
  background: linear-gradient(160deg, #1a1216 0%, #2c1f26 50%, #1a1216 100%);
  background-attachment:fixed;
}

/* ===== LAYOUT ===== */
.app{width:min(1000px,94%);margin:32px auto;position:relative;z-index:2}
.card{
  background:var(--bg-card);
  border:1px solid var(--border-glow);
  border-radius:30px;padding:32px;
  box-shadow: 0 20px 60px rgba(0,0,0,0.5);
  min-height:700px;overflow:hidden;position:relative;
  /* Removed: backdrop-filter, blur, heavy animations */
  /* Added: GPU layer hint */
  will-change: auto;
}

/* Static soft glow orbs (no animation — was the biggest lag cause) */
.card::before{
  content:"";position:absolute;top:-120px;right:-120px;width:320px;height:320px;
  background:radial-gradient(circle, rgba(212,165,176,0.15), transparent 70%);
  border-radius:50%;pointer-events:none;
}
.card::after{
  content:"";position:absolute;bottom:-140px;left:-140px;width:360px;height:360px;
  background:radial-gradient(circle, rgba(184,131,143,0.12), transparent 70%);
  border-radius:50%;pointer-events:none;
}

/* ===== HEADER ===== */
.header{text-align:center;margin-bottom:26px;position:relative;z-index:1}
.header .small-title{
  font-size:11px;letter-spacing:6px;text-transform:uppercase;
  color:var(--dusty-rose);margin-bottom:12px;font-weight:800;
}
.header h1{
  font-size:clamp(28px,6vw,54px);
  font-weight:900;letter-spacing:-0.5px;
  /* Static gradient instead of animated — huge perf win */
  background:linear-gradient(120deg, var(--cream) 0%, var(--dusty-rose) 50%, var(--cream) 100%);
  -webkit-background-clip:text;background-clip:text;color:transparent;
  text-transform:uppercase;
}
.header .edition-tag{
  margin-top:10px;font-size:12px;letter-spacing:3px;
  color:var(--rose-soft);font-weight:700;text-transform:uppercase;
}

/* ===== PROGRESS ===== */
.progress-area{margin:22px 0 32px;position:relative;z-index:1}
.progress-top{
  display:flex;justify-content:space-between;
  font-size:12px;color:var(--text-dim);margin-bottom:12px;
  font-weight:800;letter-spacing:1.5px;text-transform:uppercase;
}
.progress{
  height:10px;background:rgba(15,10,13,0.6);
  border:1px solid var(--border-soft);border-radius:50px;overflow:hidden;
}
.progress-bar{
  width:0%;height:100%;border-radius:50px;
  background:linear-gradient(90deg, var(--rose-light), var(--dusty-rose), var(--rose-deep));
  /* Simplified transition — no infinite shimmer */
  transition: width .5s ease-out;
  box-shadow:0 0 10px rgba(212,165,176,0.5);
}

/* ===== SCREENS ===== */
.screen{display:none}
.screen.active{display:block;animation:screenEnter .35s ease-out}
@keyframes screenEnter{
  from{opacity:0;transform:translateY(12px)}
  to{opacity:1;transform:translateY(0)}
}

/* ===== HERO ===== */
.hero{text-align:center;padding:42px 12px 22px}
.hero-emoji{
  font-size:82px;display:inline-block;
  animation:heroFloat 3s ease-in-out infinite;
}
@keyframes heroFloat{
  0%,100%{transform:translateY(0)}
  50%    {transform:translateY(-10px)}
}
.hero h2{
  font-size:clamp(22px,5vw,38px);margin:20px 0;color:var(--cream);
  font-weight:800;letter-spacing:-0.3px;
}
.hero p{color:var(--text-dim);line-height:1.75;max-width:660px;margin:auto;font-size:16px}

/* ===== BUTTONS ===== */
.buttons{display:flex;justify-content:center;gap:16px;flex-wrap:wrap;margin-top:32px}
button{border:none;cursor:pointer;font:inherit}
.btn{
  padding:15px 30px;border-radius:50px;font-weight:800;
  letter-spacing:1.2px;text-transform:uppercase;font-size:13px;
  transition: transform .2s ease, box-shadow .2s ease;
}
.btn:hover{transform:translateY(-3px)}
.btn:active{transform:translateY(0)}

.primary{
  background:linear-gradient(135deg, var(--dusty-rose), var(--rose-deep));
  color:var(--cream);
  box-shadow:0 8px 20px rgba(184,131,143,0.4);
}
.primary:hover{
  box-shadow:0 12px 28px rgba(212,165,176,0.55);
}

.secondary{
  background:var(--bg-elevated);
  color:var(--dusty-rose);
  border:2px solid rgba(212,165,176,0.45);
}
.secondary:hover{
  border-color:var(--dusty-rose);
  color:var(--cream);
}

.no-button{position:relative;transition:transform .2s}

/* ===== QUESTION TITLES ===== */
.question-title{
  text-align:center;font-size:clamp(22px,4vw,34px);
  margin:10px auto 24px;max-width:760px;
  color:var(--cream);font-weight:800;letter-spacing:-0.3px;
}
.question-subtitle{text-align:center;color:var(--text-dim);margin-bottom:26px;font-size:15px}

/* ===== IMAGES ===== */
.food-image{
  width:100%;height:190px;object-fit:cover;
  border-radius:18px;display:block;
  background:var(--mauve-soft);
  transition:transform .3s ease;
}

/* ===== FOOD CATEGORY GRID ===== */
.food-category-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:20px;margin-top:26px}
.food-category{
  cursor:pointer;border-radius:24px;overflow:hidden;
  background:var(--bg-elevated);
  border:2px solid var(--border-soft);
  transition: transform .25s ease, border-color .25s ease;
  position:relative;
}
.food-category:hover{
  transform:translateY(-6px);
  border-color:var(--dusty-rose);
}
.food-category:hover .food-image{transform:scale(1.04)}
.food-category.selected{
  border-color:var(--rose-light);
  box-shadow:0 0 0 3px rgba(212,165,176,0.2);
}
.food-category.selected::before{
  content:"✓";position:absolute;top:14px;right:14px;
  width:34px;height:34px;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(135deg, var(--rose-light), var(--rose-deep));
  color:var(--cream);border-radius:50%;font-weight:900;z-index:3;
}
.food-category-content{padding:16px;text-align:center}
.food-category-content h3{margin-bottom:5px;color:var(--cream);font-weight:800}
.food-category-content p{font-size:13px;color:var(--text-dim)}

/* ===== FOOD DETAIL ===== */
.food-detail{display:none;margin-top:32px}
.food-detail.active{display:block;animation:detailRise .3s ease-out}
@keyframes detailRise{
  from{opacity:0;transform:translateY(14px)}
  to{opacity:1;transform:translateY(0)}
}

.section-heading{text-align:center;margin:18px 0 22px}
.section-heading h3{font-size:24px;color:var(--cream);font-weight:800}
.section-heading p{color:var(--text-dim);margin-top:6px;font-size:14px}

/* ===== OPTION GRID ===== */
.option-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:20px;margin-top:22px}
.option{position:relative}
.option input{position:absolute;opacity:0}
.option label{
  display:block;padding:16px;border-radius:22px;
  background:var(--bg-elevated);
  border:2px solid var(--border-soft);
  cursor:pointer;height:100%;overflow:hidden;
  transition: transform .2s ease, border-color .2s ease;
}
.option label:hover{
  transform:translateY(-4px);
  border-color:var(--dusty-rose);
}
.option input:checked + label{
  border-color:var(--rose-light);
  background:rgba(212,165,176,0.12);
  box-shadow:0 0 0 3px rgba(212,165,176,0.2);
}
.option-title{font-size:16px;font-weight:800;margin-top:12px;color:var(--cream);text-align:center}

/* ===== FLAVOR GRID ===== */
.flavor-grid{
  width:100%;max-width:1100px;margin:26px auto;
  display:grid;grid-template-columns:repeat(4,minmax(0,1fr));
  gap:20px;padding:8px;
}
.flavor{
  position:relative;overflow:hidden;
  background:var(--bg-elevated);
  border:2px solid var(--border-soft);
  border-radius:22px;cursor:pointer;text-align:center;
  transition: transform .25s ease, border-color .25s ease;
}
.flavor img{
  display:block;width:100%;height:170px;object-fit:cover;
  border-radius:19px 19px 0 0;
  transition:transform .3s ease;
}
.flavor-name{
  display:block;padding:14px 8px 16px;
  font-size:15px;font-weight:800;color:var(--cream);
  background:rgba(26,18,22,0.9);
  letter-spacing:0.3px;
}
.flavor:hover{
  transform:translateY(-6px);
  border-color:var(--dusty-rose);
}
.flavor:hover img{transform:scale(1.04)}
.flavor.selected{
  border-color:var(--rose-light);
  box-shadow:0 0 0 3px rgba(212,165,176,0.22);
}
.flavor.selected::after{
  content:"✓";position:absolute;top:12px;right:12px;
  width:34px;height:34px;display:flex;align-items:center;justify-content:center;
  background:linear-gradient(135deg, var(--rose-light), var(--rose-deep));
  color:var(--cream);border-radius:50%;font-weight:900;
}

/* ===== TEXTAREA ===== */
textarea{
  width:100%;min-height:130px;resize:vertical;
  border:none;outline:none;border-radius:20px;padding:18px;
  font:inherit;background:rgba(26,18,22,0.75);
  color:var(--text-main);
  box-shadow:inset 0 0 0 2px var(--border-soft);
  margin-top:15px;transition:box-shadow .2s ease;
}
textarea:focus{box-shadow:inset 0 0 0 2px var(--dusty-rose)}
textarea::placeholder{color:var(--text-dim)}

/* ===== ICE CREAM COMPANIES ===== */
.icecream-companies{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:20px}
.company-card{
  background:var(--bg-elevated);border-radius:22px;padding:14px;
  cursor:pointer;border:2px solid var(--border-soft);
  transition: transform .25s ease, border-color .25s ease;
  text-align:center;
}
.company-card img{
  width:100%;height:120px;object-fit:contain;
  border-radius:16px;background:#fff;padding:6px;
}
.company-card h4{margin-top:12px;font-size:15px;color:var(--cream);font-weight:800}
.company-card:hover{
  transform:translateY(-5px);
  border-color:var(--dusty-rose);
}
.company-card.selected{
  border-color:var(--rose-light);
  background:rgba(212,165,176,0.12);
  box-shadow:0 0 0 3px rgba(212,165,176,0.2);
}

/* ===== MEETING BOX ===== */
.meeting-box{
  background:var(--bg-elevated);border-radius:24px;padding:28px;margin-top:22px;
  border:1px solid var(--border-soft);
}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:18px}
.field{margin-bottom:20px}
.field label{
  display:block;font-weight:800;margin-bottom:10px;
  color:var(--dusty-rose);font-size:12px;
  letter-spacing:1.6px;text-transform:uppercase;
}
input[type="date"],select{
  width:100%;padding:14px 16px;
  border:1px solid var(--border-soft);outline:none;
  border-radius:16px;background:rgba(26,18,22,0.85);
  font:inherit;color:var(--text-main);
  transition:border-color .2s ease;
}
input[type="date"]:focus,select:focus{border-color:var(--dusty-rose)}

/* ===== ACTIVITY GRID ===== */
.activity-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:18px;margin-top:22px}
.activity{position:relative}
.activity input{position:absolute;opacity:0}
.activity label{
  display:block;padding:22px;background:var(--bg-elevated);
  border-radius:20px;border:2px solid var(--border-soft);
  cursor:pointer;transition:transform .2s ease, border-color .2s ease;
  text-align:center;color:var(--text-main);
}
.activity label:hover{border-color:var(--dusty-rose);transform:translateY(-3px)}
.activity input:checked + label{
  border-color:var(--rose-light);
  background:rgba(212,165,176,0.12);
  box-shadow:0 0 0 3px rgba(212,165,176,0.2);
}

/* ===== CONDITIONAL ===== */
.conditional{display:none;margin-top:22px}
.conditional.active{display:block;animation:detailRise .3s ease-out}

/* ===== NEXT AREA ===== */
.next-area{display:flex;justify-content:center;gap:14px;margin-top:32px;flex-wrap:wrap}

/* ===== THANK YOU ===== */
.thank-you{text-align:center;padding:50px 20px}
.big-heart{
  font-size:100px;display:inline-block;
  animation:heartBeat 1.4s ease-in-out infinite;
}
@keyframes heartBeat{
  0%,100%{transform:scale(1)}
  15%{transform:scale(1.15)}
  30%{transform:scale(1)}
  45%{transform:scale(1.1)}
}

/* ===== SURPRISE ===== */
.surprise-reveal-section{text-align:center;padding:48px 20px}
.surprise-reveal-icon{
  font-size:92px;margin-bottom:22px;display:inline-block;
  animation:surprisePulse 2s ease-in-out infinite;cursor:pointer;
}
@keyframes surprisePulse{
  0%,100%{transform:scale(1)}
  50%    {transform:scale(1.1)}
}
.surprise-reveal-content{
  display:none;margin-top:26px;padding:32px;border-radius:26px;
  background:rgba(212,165,176,0.1);
  border:2px solid rgba(212,165,176,0.4);
}
.surprise-reveal-content.show{
  display:block;
  animation:revealBloom .5s ease-out;
}
@keyframes revealBloom{
  from{opacity:0;transform:scale(.9)}
  to{opacity:1;transform:scale(1)}
}

.win-banner{
  display:inline-block;margin:10px auto 22px;padding:14px 34px;
  background:linear-gradient(135deg, var(--dusty-rose), var(--rose-deep));
  color:var(--cream);border-radius:50px;font-size:20px;font-weight:900;
  letter-spacing:3px;text-transform:uppercase;
}

/* ===== DIVIDER ===== */
.section-divider{
  display:flex;align-items:center;justify-content:center;
  gap:16px;margin:44px auto 32px;max-width:620px;
}
.section-divider::before,.section-divider::after{
  content:"";flex:1;height:1.5px;
  background:linear-gradient(90deg, transparent, rgba(212,165,176,0.55), transparent);
}
.section-divider span{
  display:flex;align-items:center;justify-content:center;
  width:52px;height:52px;
  background:var(--bg-elevated);
  border:2px solid var(--dusty-rose);border-radius:50%;
  font-size:24px;
}

/* ===== SPECIAL QUESTION ===== */
.special-question-section{
  max-width:560px;margin:0 auto;padding:32px 26px;
  background:rgba(212,165,176,0.08);
  border:2px solid rgba(212,165,176,0.35);border-radius:28px;
  text-align:center;
}
.special-question-icon{
  font-size:52px;margin-bottom:16px;display:inline-block;
}
.special-question-title{font-size:20px;color:var(--cream);margin-bottom:26px;font-weight:800}
.reveal-btn{
  display:inline-flex;align-items:center;gap:10px;
  padding:15px 26px;
  background:linear-gradient(135deg, var(--dusty-rose), var(--rose-deep));
  color:var(--cream);border-radius:50px;font-weight:800;
  font-size:13px;letter-spacing:1.4px;text-transform:uppercase;
  cursor:pointer;border:none;
  transition:transform .2s ease;
}
.reveal-btn:hover{transform:translateY(-3px)}
.special-reason{margin-top:26px}
.reason-content{
  padding:22px;background:rgba(26,18,22,0.85);
  border-radius:20px;border:2px solid rgba(212,165,176,0.3);
}
.reason-emoji{font-size:42px;margin-bottom:12px}
.reason-text{font-size:18px;font-weight:800;color:var(--dusty-rose);margin-bottom:12px}
.reason-hearts{font-size:24px}

/* ===== CONTACT ===== */
.contact-section{max-width:560px;margin:0 auto;text-align:center}
.contact-section-title{font-size:22px;color:var(--cream);margin-bottom:22px;font-weight:800}
.contact-card{
  padding:30px 24px;
  background:rgba(212,165,176,0.06);
  border:2px solid rgba(212,165,176,0.3);border-radius:28px;
}
.contact-icon{font-size:50px;margin-bottom:10px}
.contact-card h3{font-size:20px;margin-bottom:10px;color:var(--cream)}
.contact-card p{color:var(--text-dim);line-height:1.65;margin-bottom:16px;font-size:14px}
.phone-number{
  display:inline-block;padding:11px 22px;margin:6px 0 10px;
  background:rgba(26,18,22,0.9);
  border:1px solid rgba(212,165,176,0.4);border-radius:50px;
  font-size:17px;font-weight:900;color:var(--dusty-rose);
  letter-spacing:1px;
}
.contact-buttons{display:flex;justify-content:center;flex-wrap:wrap;gap:12px;margin-top:22px}
.contact{
  display:inline-flex;align-items:center;gap:8px;text-decoration:none;
  padding:13px 24px;border-radius:50px;font-weight:800;font-size:12px;
  letter-spacing:1.3px;text-transform:uppercase;
  transition:transform .2s ease;
}
.contact:hover{transform:translateY(-3px)}
.call{
  background:linear-gradient(135deg, var(--dusty-rose), var(--rose-deep));
  color:var(--cream);
}
.message{
  background:linear-gradient(135deg, var(--rose-light), var(--rose-mid));
  color:var(--deep-mauve);
}
.whatsapp{
  background:linear-gradient(135deg, var(--cream-soft), var(--rose-light));
  color:var(--deep-mauve);
}

/* ===== FRIENDSHIP LEVEL ===== */
.level{
  font-size:clamp(32px,7vw,62px);font-weight:900;
  background:linear-gradient(120deg, var(--cream), var(--dusty-rose), var(--rose-deep));
  -webkit-background-clip:text;background-clip:text;color:transparent;
}
.level-bar{
  height:18px;background:rgba(15,10,13,0.6);
  border:1px solid var(--border-soft);border-radius:50px;overflow:hidden;
  margin:22px auto;max-width:620px;
}
.level-fill{
  height:100%;width:0;
  background:linear-gradient(90deg, var(--rose-light), var(--dusty-rose), var(--rose-deep));
  transition: width 1.2s ease-out;
}

/* ===== TOAST ===== */
.toast{
  position:fixed;left:50%;bottom:28px;
  transform:translate(-50%,120px);
  background:var(--cream);
  color:var(--deep-mauve);
  border:1px solid rgba(212,165,176,0.6);
  padding:14px 26px;border-radius:50px;z-index:9999;
  opacity:0;transition: transform .3s ease, opacity .3s ease;
  pointer-events:none;font-weight:800;font-size:14px;
  box-shadow:0 10px 30px rgba(0,0,0,0.5);
}
.toast.show{opacity:1;transform:translate(-50%,0)}

/* ===== CONFETTI ===== */
.confetti{
  position:fixed;width:12px;height:16px;top:-24px;z-index:9998;
  animation:confettiFall linear forwards;pointer-events:none;font-size:20px;
  will-change: transform;
}
@keyframes confettiFall{
  to{transform:translateY(112vh) rotate(720deg);opacity:0}
}

/* ===== OX GAME ===== */
.ox-game-section{max-width:640px;margin:0 auto;text-align:center;padding:16px 5px 26px}
.ox-badge{
  display:inline-flex;padding:8px 20px;margin-bottom:14px;
  border-radius:999px;background:var(--bg-elevated);
  border:1px solid rgba(212,165,176,0.5);
  color:var(--dusty-rose);font-size:11px;font-weight:900;
  letter-spacing:3px;text-transform:uppercase;
}
.ox-status-card{
  display:flex;align-items:center;justify-content:center;gap:16px;
  margin:22px auto 18px;max-width:440px;padding:16px 22px;
  border-radius:22px;background:var(--bg-elevated);
  border:2px solid rgba(212,165,176,0.35);
}
.ox-turn-icon{
  width:46px;height:46px;display:flex;align-items:center;justify-content:center;
  border-radius:50%;background:rgba(212,165,176,0.15);
  border:1px solid rgba(212,165,176,0.45);font-size:24px;
}
.ox-status-card strong{display:block;color:var(--cream);font-size:15px;font-weight:800}
.ox-status-card span{display:block;margin-top:3px;color:var(--text-dim);font-size:12px}
.ox-board-wrap{display:flex;justify-content:center;margin:26px auto}
.ox-board{
  width:min(92vw,400px);aspect-ratio:1;
  display:grid;grid-template-columns:repeat(3,1fr);gap:12px;
  padding:12px;border-radius:28px;
  background:rgba(212,165,176,0.06);
  border:2px solid rgba(212,165,176,0.4);
}
.ox-cell{
  border:0;border-radius:20px;background:rgba(26,18,22,0.9);
  box-shadow:inset 0 0 0 2px rgba(212,165,176,0.22);
  cursor:pointer;font-size:clamp(42px,11vw,68px);font-weight:900;
  line-height:1;color:var(--dusty-rose);
  transition:transform .15s ease, background .15s ease;
}
.ox-cell:hover:not(.filled){
  transform:translateY(-4px) scale(1.03);
  background:rgba(212,165,176,0.12);
}
.ox-cell.filled{cursor:default}
.ox-cell.player{color:var(--rose-light)}
.ox-cell.computer{color:var(--rose-deep)}
.ox-cell.win{
  background:rgba(212,165,176,0.2);
  box-shadow:0 0 0 3px rgba(212,165,176,0.5);
}
.ox-result{
  min-height:130px;margin:18px auto 0;padding:24px;
  border-radius:24px;background:var(--bg-elevated);
  border:2px solid var(--border-soft);
}
.ox-result.win{border-color:rgba(212,165,176,0.7)}
.ox-result-icon{font-size:40px;margin-bottom:8px}
.ox-result h3{color:var(--cream);font-size:20px;font-weight:800}
.ox-result p{margin-top:8px;color:var(--text-dim);line-height:1.6;font-size:14px}
.ox-actions{display:flex;justify-content:center;gap:14px;flex-wrap:wrap;margin-top:24px}
.ox-continue-btn:disabled{opacity:.4;cursor:not-allowed}
.ox-progress-row{
  width:min(100%,530px);margin:16px auto 10px;
  display:flex;justify-content:space-between;
  padding:11px 18px;border-radius:16px;
  background:var(--bg-elevated);
  border:1px solid rgba(212,165,176,0.3);
  color:var(--dusty-rose);font-weight:800;font-size:13px;
  letter-spacing:0.5px;
}
.ox-five-message{
  width:min(100%,530px);margin:0 auto 16px;padding:12px 18px;
  border-radius:14px;background:rgba(212,165,176,0.08);
  border:1px solid rgba(212,165,176,0.22);
  color:var(--text-dim);font-size:13px;font-weight:700;
  transition:all .25s ease;
}
.ox-five-message.ready{
  background:rgba(212,165,176,0.18);
  border-color:rgba(212,165,176,0.6);
  color:var(--rose-light);
}

/* ===== MEETING SUMMARY ===== */
.meeting-summary-card{
  margin:26px auto 0;max-width:640px;padding:24px;
  border-radius:22px;
  background:rgba(212,165,176,0.08);
  border:1px solid rgba(212,165,176,0.35);text-align:left;
}
.meeting-summary-card h3{margin:0 0 14px;color:var(--dusty-rose);font-size:18px;font-weight:800}
.meeting-summary-card p{margin:8px 0;color:var(--text-main);line-height:1.6;font-size:14px}
.meeting-summary-card strong{color:var(--rose-light)}

/* ===== PARTICLES (much fewer + lighter) ===== */
.particles{position:fixed;inset:0;pointer-events:none;overflow:hidden;z-index:1}
.particle{
  position:absolute;bottom:-50px;font-size:18px;
  animation:floatParticle linear infinite;
  will-change: transform;
}
@keyframes floatParticle{
  0%{transform:translateY(0);opacity:0}
  10%{opacity:.7}
  90%{opacity:.5}
  100%{transform:translateY(-105vh);opacity:0}
}

/* ===== RESPONSIVE ===== */
@media (max-width:900px){.flavor-grid{grid-template-columns:repeat(3,minmax(0,1fr))}}
@media (max-width:700px){
  .app{width:96%;margin:14px auto}
  .card{padding:20px;border-radius:24px}
  .food-category-grid{grid-template-columns:1fr}
  .form-row{grid-template-columns:1fr}
  .btn{width:100%}
  .buttons{flex-direction:column}
  .contact-buttons{flex-direction:column}
  .contact{width:100%}
  .ox-actions .btn{width:100%}
}
@media (max-width:650px){.flavor-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media (max-width:420px){
  .flavor-grid{grid-template-columns:1fr;max-width:360px}
}

/* ===== REDUCED MOTION ===== */
@media (prefers-reduced-motion: reduce){
  *,*::before,*::after{
    animation-duration:.01ms !important;
    animation-iteration-count:1 !important;
    transition-duration:.01ms !important;
  }
}
</style>
</head>
<body>

<div class="particles" id="particles"></div>

<div class="app">
<div class="card">

<div class="header">
  <div class="small-title">A little game made with love</div>
  <h1>Your Nick's Quize</h1>
  <div class="edition-tag">✦ Elegant Edition ✦</div>
</div>

<div class="progress-area">
  <div class="progress-top">
    <span id="progressText">Ready? 💛</span>
    <span id="stepText">1 / 10</span>
  </div>
  <div class="progress"><div class="progress-bar" id="progressBar"></div></div>
</div>

<!-- SCREEN 1 -->
<section class="screen active" data-step="1">
<div class="hero">
  <div class="hero-emoji">💛</div>
  <h2>Do You Want to Play This Game?</h2>
  <p>A sweet little quiz made especially for my favorite SWEETIE. Cute questions, some food, some memories, and one big surprise at the end. ✨</p>
  <h3 style="margin-top:20px;color:var(--dusty-rose);font-size:15px;letter-spacing:2.5px;font-weight:800;">TRY TO CLICK ON "NO" BUTTON 😏</h3>
  <div class="buttons">
    <button class="btn primary" onclick="nextScreen()">Yes 💛</button>
    <button class="btn secondary no-button" id="noButton">No 😏</button>
  </div>
</div>
</section>

<!-- SCREEN 2 — FOOD -->
<section class="screen" data-step="2">
<h2 class="question-title">🍽️ Let's Talk About Food</h2>
<p class="question-subtitle">Choose one food category first.</p>

<div class="food-category-grid">
  <div class="food-category" data-category="street" onclick="selectFoodCategory('street', this)">
    <img class="food-image" src="Street Food .jpg" alt="Street Food" onerror="imgFallback(this,'Street Food','8a5c67','faf3f0')">
    <div class="food-category-content"><h3>🌮 Street Food</h3><p>Spicy, crispy and fun.</p></div>
  </div>
  <div class="food-category" data-category="homemade" onclick="selectFoodCategory('homemade', this)">
    <img class="food-image" src="Home Made.jpg" alt="Homemade Food" onerror="imgFallback(this,'Homemade Food','b8838f','faf3f0')">
    <div class="food-category-content"><h3>🥘 Homemade Food</h3><p>Comfort food made with love.</p></div>
  </div>
  <div class="food-category" data-category="custom" onclick="selectFoodCategory('custom', this)">
    <img class="food-image" src="ChatGPT Image Aug 20, 2026, 08_06_55 PM.png" alt="What I Make" onerror="imgFallback(this,'What I Make','d4a5b0','2c1f26')">
    <div class="food-category-content"><h3>👨‍🍳 What I Make</h3><p>Tell me what you'd like me to make.</p></div>
  </div>
</div>

<div class="food-detail" id="streetDetail">
<div class="section-heading"><h3>🌮 Choose Your Street Food</h3></div>
<div class="option-grid">
  <div class="option"><input type="radio" name="street_food" id="street1" value="Pani Puri"><label for="street1"><img class="food-image" src="Pani Puri.jpg" alt="Pani Puri" onerror="imgFallback(this,'Pani Puri','8a5c67','faf3f0')"><div class="option-title">Pani Puri 🥙</div></label></div>
  <div class="option"><input type="radio" name="street_food" id="street2" value="Vada Pav"><label for="street2"><img class="food-image" src="vada [av.jpg" alt="Vada Pav" onerror="imgFallback(this,'Vada Pav','b8838f','faf3f0')"><div class="option-title">Vada Pav 🍔</div></label></div>
  <div class="option"><input type="radio" name="street_food" id="street3" value="Dabeli"><label for="street3"><img class="food-image" src="Dabeli.jpg" alt="Dabeli" onerror="imgFallback(this,'Dabeli','d4a5b0','2c1f26')"><div class="option-title">Dabeli 🌮</div></label></div>
  <div class="option"><input type="radio" name="street_food" id="street4" value="Pav Bhaji"><label for="street4"><img class="food-image" src="Pav Bhagi.jpg" alt="Pav Bhaji" onerror="imgFallback(this,'Pav Bhaji','ecd0d6','2c1f26')"><div class="option-title">Pav Bhaji 🥪</div></label></div>
</div>
</div>

<div class="food-detail" id="homemadeDetail">
<div class="section-heading"><h3>🥘 Choose Your Vegetable Dish</h3></div>
<div class="option-grid">
  <div class="option"><input type="radio" name="homemade_food" id="home1" value="Bhindi Masala"><label for="home1"><img class="food-image" src="Bhindi Masala.jpg" alt="Bhindi Masala" onerror="imgFallback(this,'Bhindi Masala','8a5c67','faf3f0')"><div class="option-title">Bhindi Masala 🥘</div></label></div>
  <div class="option"><input type="radio" name="homemade_food" id="home2" value="Paneer"><label for="home2"><img class="food-image" src="Paneer.jpg" alt="Paneer" onerror="imgFallback(this,'Paneer','b8838f','faf3f0')"><div class="option-title">Paneer 🧀</div></label></div>
  <div class="option"><input type="radio" name="homemade_food" id="home3" value="Dal Tadka"><label for="home3"><img class="food-image" src="Dal tadka.jpg" alt="Dal Tadka" onerror="imgFallback(this,'Dal Tadka','d4a5b0','2c1f26')"><div class="option-title">Dal Tadka 🍲</div></label></div>
  <div class="option"><input type="radio" name="homemade_food" id="home4" value="Rajma-Chawal"><label for="home4"><img class="food-image" src="Rajma-Chawal.webp" alt="Rajma Chawal" onerror="imgFallback(this,'Rajma Chawal','ecd0d6','2c1f26')"><div class="option-title">Rajma-Chawal 🥗</div></label></div>
</div>
<div class="section-heading" style="margin-top:36px"><h3>🫓 Choose Your Roti</h3></div>
<div class="option-grid">
  <div class="option"><input type="radio" name="roti_type" id="normalRoti" value="Normal Roti"><label for="normalRoti"><img class="food-image" src="Normal Roti.jpg" alt="Normal Roti" onerror="imgFallback(this,'Normal Roti','3d2b33','faf3f0')"><div class="option-title">🫓 Normal Roti</div></label></div>
  <div class="option"><input type="radio" name="roti_type" id="butterRoti" value="Butter Roti"><label for="butterRoti"><img class="food-image" src="Buttor Roti.jpg" alt="Butter Roti" onerror="imgFallback(this,'Butter Roti','8a5c67','faf3f0')"><div class="option-title">🧈🫓 Butter Roti</div></label></div>
</div>
</div>

<div class="food-detail" id="customDetail">
<div class="section-heading"><h3>👨‍🍳 What Should I Make?</h3></div>
<textarea id="customFood" placeholder="Tell me what food you want me to make... ✨"></textarea>
</div>

<div class="next-area"><button class="btn primary" onclick="nextFood()">Continue to Ice Cream 🍦</button></div>
</section>

<!-- SCREEN 3 — ICE CREAM -->
<section class="screen" data-step="3">
<h2 class="question-title">🍦 Ice Cream Time!</h2>
<p class="question-subtitle">First choose a company, then choose your flavor.</p>
<div class="icecream-companies">
  <div class="company-card" data-company="Vadilal" onclick="selectCompany('Vadilal',this)"><img src="Vadilal Logo.png" alt="Vadilal" onerror="imgFallback(this,'Vadilal','faf3f0','8a5c67')"><h4>Vadilal</h4></div>
  <div class="company-card" data-company="Amul" onclick="selectCompany('Amul',this)"><img src="Amul Logo.JPEG.avif" alt="Amul" onerror="imgFallback(this,'Amul','faf3f0','8a5c67')"><h4>Amul</h4></div>
  <div class="company-card" data-company="Kwality Walls" onclick="selectCompany('Kwality Walls',this)"><img src="Kwality Walls.jpg" alt="Kwality Walls" onerror="imgFallback(this,'Kwality Walls','faf3f0','8a5c67')"><h4>Kwality Walls</h4></div>
  <div class="company-card" data-company="Hokey Pokey" onclick="selectCompany('Hokey Pokey',this)"><img src="Hokey Pokey.jpg" alt="Hokey Pokey" onerror="imgFallback(this,'Hokey Pokey','faf3f0','8a5c67')"><h4>Hokey Pokey</h4></div>
</div>
<div class="section-heading"><h3 id="flavorTitle">🍨 Choose Your Flavor</h3></div>
<div class="flavor-grid">
  <div class="flavor" onclick="selectFlavor(this,'Chocolate')"><img src="Chocolate.jpg" alt="Chocolate" onerror="imgFallback(this,'Chocolate','8a5c67','faf3f0')"><span class="flavor-name">🍫 Chocolate</span></div>
  <div class="flavor" onclick="selectFlavor(this,'Vanilla')"><img src="vanilla.jpg" alt="Vanilla" onerror="imgFallback(this,'Vanilla','ecd0d6','2c1f26')"><span class="flavor-name">🍦 Vanilla</span></div>
  <div class="flavor" onclick="selectFlavor(this,'Strawberry')"><img src="Strawberry.jpg" alt="Strawberry" onerror="imgFallback(this,'Strawberry','d4a5b0','2c1f26')"><span class="flavor-name">🍓 Strawberry</span></div>
  <div class="flavor" onclick="selectFlavor(this,'Butterscotch')"><img src="Butterscotch.jpg" alt="Butterscotch" onerror="imgFallback(this,'Butterscotch','b8838f','faf3f0')"><span class="flavor-name">🍯 Butterscotch</span></div>
  <div class="flavor" onclick="selectFlavor(this,'Mango')"><img src="Mango.jpg" alt="Mango" onerror="imgFallback(this,'Mango','d4a5b0','2c1f26')"><span class="flavor-name">🥭 Mango</span></div>
  <div class="flavor" onclick="selectFlavor(this,'Cookies & Cream')"><img src="Cookies & Cream.jpg" alt="Cookies" onerror="imgFallback(this,'Cookies & Cream','3d2b33','faf3f0')"><span class="flavor-name">🍪 Cookies & Cream</span></div>
  <div class="flavor" onclick="selectFlavor(this,'PISTA')"><img src="PISTA.jpg" alt="PISTA" onerror="imgFallback(this,'PISTA','8a5c67','faf3f0')"><span class="flavor-name">🟢 PISTA</span></div>
  <div class="flavor" onclick="selectFlavor(this,'Caramel')"><img src="Caramel.jpg" alt="Caramel" onerror="imgFallback(this,'Caramel','b8838f','faf3f0')"><span class="flavor-name">🍯 Caramel</span></div>
</div>
<div class="next-area"><button class="btn primary" onclick="nextIceCream()">Continue 🌸</button></div>
</section>

<!-- SCREEN 4 — COMFORT -->
<section class="screen" data-step="4">
<div class="hero">
  <div class="hero-emoji">💬</div>
  <h2>Do you feel comefortable and happy after talking to me??</h2>
  <p>Be honest... there is no wrong answer. ✨</p>
  <div class="buttons">
    <button class="btn primary" onclick="comfortableYes()">Yes 🌸</button>
    <button class="btn secondary" onclick="comfortableMeeting()">I will tell you when we meet ✨</button>
  </div>
</div>
</section>

<!-- SCREEN 5 — OX GAME -->
<section class="screen" data-step="5">
<div class="ox-game-section">
  <div class="ox-badge">🎮 Mini Challenge</div>
  <h2 class="question-title">❌⭕ OX Game — Your Little Challenge</h2>
  <p class="question-subtitle">Fill 5 spaces and win the game to unlock the hangout! ✨</p>
  <div class="ox-progress-row"><span>Board filled</span><strong><span id="oxFilledCount">0</span> / 5</strong></div>
  <div class="ox-five-message" id="oxFiveMessage">Fill 5 spaces and win to unlock the meeting step. ✨</div>
  <div class="ox-status-card">
    <div class="ox-turn-icon" id="oxTurnIcon">❌</div>
    <div><strong id="oxStatus">Your turn!</strong><span>You are ❌ | Computer is ⭕</span></div>
  </div>
  <div class="ox-board-wrap">
    <div class="ox-board" id="oxBoard">
      <button class="ox-cell" data-index="0" onclick="oxMove(0)"></button>
      <button class="ox-cell" data-index="1" onclick="oxMove(1)"></button>
      <button class="ox-cell" data-index="2" onclick="oxMove(2)"></button>
      <button class="ox-cell" data-index="3" onclick="oxMove(3)"></button>
      <button class="ox-cell" data-index="4" onclick="oxMove(4)"></button>
      <button class="ox-cell" data-index="5" onclick="oxMove(5)"></button>
      <button class="ox-cell" data-index="6" onclick="oxMove(6)"></button>
      <button class="ox-cell" data-index="7" onclick="oxMove(7)"></button>
      <button class="ox-cell" data-index="8" onclick="oxMove(8)"></button>
    </div>
  </div>
  <div class="ox-result" id="oxResult">
    <div class="ox-result-icon" id="oxResultIcon">✨</div>
    <h3 id="oxResultTitle">Win the game to continue 🌸</h3>
    <p id="oxResultMessage">Get three ❌ in a row, column, or diagonal.</p>
  </div>
  <div class="ox-actions">
    <button class="btn secondary" onclick="resetOXGame()">🔄 Play Again</button>
    <button class="btn primary ox-continue-btn" id="oxContinueBtn" onclick="continueAfterOX()" disabled>Continue to Meeting 📅</button>
  </div>
</div>
</section>

<!-- SCREEN 6 — MEETING -->
<section class="screen" data-step="6">
<h2 class="question-title">📅 When Do You Want To Meet Me??</h2>
<div class="meeting-box">
  <div class="form-row">
    <div class="field"><label>📅 Select Date</label><input type="date" id="meetingDate"></div>
    <div class="field"><label>⏰ Select Time</label><select id="meetingTime"><option value="">Select Time</option></select></div>
  </div>
  <div class="section-heading"><h3>✨ What Can We Do?</h3><p>Choose two or three options.</p></div>
  <div class="activity-grid">
    <div class="activity"><input type="checkbox" id="movie" value="Watch Movie" onchange="toggleActivity('movie')"><label for="movie"><div style="font-size:35px;">🎬</div>Watch Movie</label></div>
    <div class="activity"><input type="checkbox" id="garden" value="Garden / Pleasant Place" onchange="toggleActivity('garden')"><label for="garden"><div style="font-size:35px;">🌳</div>Garden / Pleasant Place</label></div>
    <div class="activity"><input type="checkbox" id="mall" value="Mall" onchange="toggleActivity('mall')"><label for="mall"><div style="font-size:35px;">🛍️</div>Nice Mall</label></div>
    <div class="activity"><input type="checkbox" id="sport" value="Badminton / Sport" onchange="toggleActivity('sport')"><label for="sport"><div style="font-size:35px;">🏸</div>Badminton / Sport</label></div>
  </div>
  <div class="conditional" id="movieBox"><div class="field"><label>🎬 Movie Category</label><select id="movieCategory"><option value="">Select one</option><option>Comedy 😂</option><option>Romantic 💕</option><option>Action 🔥</option><option>Horror 👻</option><option>Animation 🌈</option><option>Anything 🎥</option></select></div></div>
  <div class="conditional" id="gardenBox"><div class="field"><label>🌳 Location Type</label><select id="gardenLocation"><option value="">Select one</option><option>Quiet Garden 🌳</option><option>Pleasant Place 🌸</option><option>Lake Side 🌊</option><option>Any Peaceful Place ✨</option></select></div></div>
  <div class="conditional" id="mallBox"><div class="field"><label>🛍️ Mall Choice</label><select id="mallChoice"><option value="">Select one</option><option>Nice Shopping Mall 🛍️</option><option>Food Court 🍕</option><option>Movie + Mall 🎬</option><option>Just Walk & Talk ✨</option></select></div></div>
  <div class="conditional" id="sportBox"><div class="field"><label>🏸 Sport Choice</label><select id="sportChoice"><option value="">Select one</option><option>Badminton 🏸</option><option>Chess ♛</option><option>Table Tennis 🏓</option><option>Anything Fun 😄</option></select></div></div>
  <div class="next-area"><button class="btn primary" onclick="finishMeeting()">Fix Meeting 🌸</button></div>
</div>
</section>

<!-- SCREEN 7 — FRIENDSHIP -->
<section class="screen" data-step="7">
<div class="thank-you">
  <div class="big-heart">💛</div>
  <h2 style="color:var(--cream);font-size:30px;font-weight:800;">Friendship Level</h2>
  <div class="level" id="friendshipLevel">0%</div>
  <div class="level-bar"><div class="level-fill" id="levelFill"></div></div>
  <p style="font-size:20px;line-height:1.75;margin-top:18px;">
    <strong style="color:var(--dusty-rose);">100% 💛</strong><br>
    <span style="color:var(--text-dim);">*Best friend status confirmed.* ✨</span>
  </p>
  <div style="margin-top:26px;font-size:30px;">🥹 💛 ✨ 🌻 💛 🥹</div>
  <div class="meeting-summary-card" id="meetingSummaryCard">
    <h3>📅 Our Hangout Plan</h3>
    <p><strong>Date:</strong> <span id="summaryDate">—</span></p>
    <p><strong>Time:</strong> <span id="summaryTime">—</span></p>
    <p><strong>Activity:</strong> <span id="summaryActivity">—</span></p>
  </div>
  <div class="next-area"><button class="btn primary" onclick="nextScreen()">Continue to Surprise 🎁</button></div>
</div>
</section>

<!-- SCREEN 8 — SURPRISE -->
<section class="screen" data-step="8">
<div class="surprise-reveal-section">
  <div class="win-banner">💛 SWEETIE 💛 🏆 You Win! 🏆</div>
  <div class="surprise-reveal-icon" onclick="revealSurpriseContent(this)">🎁</div>
  <h2 style="color:var(--cream);font-size:28px;font-weight:800;">Click to Reveal Your Surprise! ✨</h2>
  <p style="margin-top:16px;color:var(--text-dim);">One final thing is waiting for you...</p>
  <div class="surprise-reveal-content" id="surpriseContent">
    <h3 style="font-size:26px;color:var(--dusty-rose);font-weight:900;">💛 SWEETIE 💛 🏆 You Win! 🏆</h3>
    <p style="margin-top:14px;font-size:18px;color:var(--cream);font-weight:800;">You completed the whole quiz! 🎉</p>
    <h3 style="font-size:22px;color:var(--cream);margin-top:20px;">✨ Surprise! ✨</h3>
    <p style="margin-top:16px;font-size:18px;color:var(--dusty-rose);font-weight:800;">You're my favorite person to hang out with! 💛</p>
    <div style="font-size:30px;margin-top:16px;">🎉 💛 ✨ 🎉</div>
  </div>
  <div class="next-area"><button class="btn primary" onclick="nextScreen()">Continue 🌸</button></div>
</div>
</section>

<!-- SCREEN 9 — SPECIAL REASON -->
<section class="screen" data-step="9">
<div class="thank-you">
  <div class="big-heart">💛</div>
  <h2 style="color:var(--cream);font-size:28px;font-weight:800;">Why You're My SWEETIE</h2>
  <p style="margin-top:16px;line-height:1.8;font-size:17px;color:var(--text-dim);">There's a special reason... ✨</p>
</div>
<div class="section-divider"><span>💛</span></div>
<div class="special-question-section">
  <div class="special-question-icon">🤔</div>
  <h3 class="special-question-title">Why do I talk only to you — like my female friend SWEETIE?? 💛</h3>
  <button class="btn reveal-btn" onclick="revealSpecialReason(this)">✨ Click to Reveal Reason ✨</button>
  <div class="special-reason" style="display:none;">
    <div class="reason-content">
      <div class="reason-emoji">😊</div>
      <p class="reason-text">I'll tell you the real reason when we Meet 💛</p>
      <div class="reason-hearts">✨ 💛 ✨</div>
    </div>
  </div>
</div>
<div class="next-area"><button class="btn primary" onclick="nextScreen()">Continue 🌸</button></div>
</section>

<!-- SCREEN 10 — CONTACT -->
<section class="screen" data-step="10">
<div class="thank-you">
  <div class="big-heart">💛</div>
  <h2 style="color:var(--cream);font-size:28px;font-weight:800;">Thank You for Playing! 🥹</h2>
  <p style="margin-top:16px;line-height:1.8;color:var(--text-dim);font-size:16px;">Made with love, just for my SWEETIE. 🌸✨</p>
</div>
<div class="section-divider"><span>📱</span></div>
<div class="contact-section">
  <h3 class="contact-section-title">Want to Talk to Me? 💛</h3>
  <div class="contact-card">
    <div class="contact-icon">📱</div>
    <h3>Let's Stay Connected! 💛</h3>
    <p>Call me or send a message — I'm one click away. 😊</p>
    <div class="phone-number">📞 +91 9265078473</div>
    <div class="contact-buttons">
      <a class="contact call" href="tel:+919265078473">📞 Call Me</a>
      <a class="contact message" href="sms:+919265078473?body=Hey%20SWEETIE%20%F0%9F%92%9B">💬 Message</a>
      <a class="contact whatsapp" href="https://wa.me/919265078473?text=Hey%20SWEETIE!" target="_blank" rel="noopener">💚 WhatsApp</a>
    </div>
  </div>
</div>
<div class="next-area"><button class="btn primary" onclick="restartQuiz()">Play Again 🔄</button></div>
</section>

</div>
</div>

<div class="toast" id="toast"></div>

<script>
/* ============ STATE ============ */
let currentScreen = 1;
const totalScreens = 10;
let selectedFoodCategory = "";
let selectedCompany = "";
let selectedFlavor = "";
let comfortableAnswer = "";
let activityChoices = [];

/* ============ DOM ============ */
const screens = document.querySelectorAll(".screen");
const progressBar = document.getElementById("progressBar");
const progressText = document.getElementById("progressText");
const stepText = document.getElementById("stepText");

/* ============ IMAGE FALLBACK ============ */
function imgFallback(el, label, bg, fg) {
  el.onerror = null;
  const w = 400, h = 250;
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}">
    <defs><linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#${bg}"/><stop offset="100%" stop-color="#2c1f26"/>
    </linearGradient></defs>
    <rect width="100%" height="100%" fill="url(#g)"/>
    <text x="50%" y="50%" font-family="Arial" font-size="20" font-weight="bold" fill="#${fg}" text-anchor="middle" dominant-baseline="middle">${label}</text>
  </svg>`;
  el.src = 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(svg);
}

/* ============ PARTICLES (reduced from 26 to 12 for performance) ============ */
(function(){
  const c = document.getElementById("particles");
  const s = ["🌸","✨","💛","🌺"];
  // Use DocumentFragment for faster insertion
  const frag = document.createDocumentFragment();
  for (let i = 0; i < 12; i++) {
    const p = document.createElement("div");
    p.className = "particle";
    p.textContent = s[i % s.length];
    p.style.left = (i * 8 + Math.random() * 6) + "%";
    p.style.animationDuration = (10 + Math.random()*8) + "s";
    p.style.animationDelay = (Math.random()*8) + "s";
    p.style.fontSize = (14 + Math.random()*10) + "px";
    frag.appendChild(p);
  }
  c.appendChild(frag);
})();

/* ============ PROGRESS ============ */
function updateProgress() {
  const p = ((currentScreen-1)/(totalScreens-1))*100;
  progressBar.style.width = p + "%";
  stepText.textContent = currentScreen + " / " + totalScreens;
  const labels = {
    1:"Ready? 🌸",2:"Food time 🍽️",3:"Ice cream 🍦",4:"A little question 💬",
    5:"OX Challenge ❌⭕",6:"Hangout plans 📅",7:"Friendship 💛",
    8:"Surprise 🎁",9:"Special Reason 💛",10:"Stay Connected 📱"
  };
  progressText.textContent = labels[currentScreen] || "Let's go!";
}

/* ============ SHOW SCREEN ============ */
function showScreen(n) {
  if (n < 1 || n > totalScreens) return;
  screens.forEach(s => s.classList.remove("active"));
  const t = document.querySelector(`.screen[data-step="${n}"]`);
  if (t) {
    t.classList.add("active");
    currentScreen = n;
    updateProgress();
    window.scrollTo({top:0,behavior:"smooth"});
    if (n === 8) {
      setTimeout(() => {
        const icon = document.querySelector(".surprise-reveal-icon");
        const content = document.getElementById("surpriseContent");
        if (icon && content && !content.classList.contains("show")) revealSurpriseContent(icon);
      }, 800);
    }
  }
}
function nextScreen() { showScreen(currentScreen + 1); }

/* ============ MOVING NO BUTTON (throttled) ============ */
const noButton = document.getElementById("noButton");
let noBtnCooldown = false;
function moveNoButton() {
  if (!noButton || noBtnCooldown) return;
  noBtnCooldown = true;
  setTimeout(() => noBtnCooldown = false, 250);
  const p = noButton.parentElement;
  const maxX = Math.max(10, p.clientWidth - noButton.offsetWidth - 10);
  const x = Math.random()*maxX - maxX/2;
  const y = Math.random()*80 - 40;
  noButton.style.transform = `translate(${x}px,${y}px) rotate(${Math.random()*8-4}deg)`;
  showToast("Nice try 😏✨");
}
if (noButton) {
  noButton.addEventListener("mouseenter", moveNoButton);
  noButton.addEventListener("touchstart", e => { e.preventDefault(); moveNoButton(); }, {passive:false});
  noButton.addEventListener("click", e => { e.preventDefault(); moveNoButton(); });
}

/* ============ FOOD CATEGORY ============ */
function selectFoodCategory(cat, el) {
  selectedFoodCategory = cat;
  document.querySelectorAll(".food-category").forEach(c => c.classList.remove("selected"));
  el.classList.add("selected");
  document.querySelectorAll(".food-detail").forEach(b => b.classList.remove("active"));
  if (cat === "street") document.getElementById("streetDetail").classList.add("active");
  if (cat === "homemade") document.getElementById("homemadeDetail").classList.add("active");
  if (cat === "custom") document.getElementById("customDetail").classList.add("active");
  showToast("Great choice! 😋");
}

/* ============ FOOD CONTINUE ============ */
function nextFood() {
  if (!selectedFoodCategory) { showToast("Choose a food category first ✨"); return; }
  if (selectedFoodCategory === "street" && !document.querySelector('input[name="street_food"]:checked')) {
    showToast("Choose your street food 🌮"); return;
  }
  if (selectedFoodCategory === "homemade") {
    if (!document.querySelector('input[name="homemade_food"]:checked')) { showToast("Choose your vegetable dish 🥘"); return; }
    if (!document.querySelector('input[name="roti_type"]:checked')) { showToast("Choose normal or butter roti 🫓"); return; }
  }
  if (selectedFoodCategory === "custom") {
    if (!document.getElementById("customFood").value.trim()) { showToast("Tell me what to make 👨‍🍳"); return; }
  }
  showScreen(3);
}

/* ============ ICE CREAM ============ */
function selectCompany(c, el) {
  selectedCompany = c;
  document.querySelectorAll(".company-card").forEach(x => x.classList.remove("selected"));
  el.classList.add("selected");
  document.getElementById("flavorTitle").textContent = "🍨 Choose Your " + c + " Flavor";
  showToast(c + " selected 🍦");
}
function selectFlavor(el, f) {
  selectedFlavor = f;
  document.querySelectorAll(".flavor").forEach(x => x.classList.remove("selected"));
  el.classList.add("selected");
  showToast(f + " sounds delicious! 🍦");
}
function nextIceCream() {
  if (!selectedCompany) { showToast("Choose an ice cream company 🍦"); return; }
  if (!selectedFlavor) { showToast("Choose your favorite flavor 🍨"); return; }
  showScreen(4);
}

/* ============ COMFORT ============ */
function comfortableYes() {
  comfortableAnswer = "Yes";
  showScreen(5); createConfetti(); showToast("Thank you SWEETIE! ✨");
}
function comfortableMeeting() {
  comfortableAnswer = "I will tell you when we meet";
  resetOXGame(); showScreen(5); showToast("First, win the OX game! ❌⭕");
}

/* ============ ACTIVITY ============ */
function toggleActivity(a) {
  const cb = document.getElementById(a);
  const box = document.getElementById(a + "Box");
  if (cb.checked) {
    box.classList.add("active");
    if (!activityChoices.includes(cb.value)) activityChoices.push(cb.value);
  } else {
    box.classList.remove("active");
    activityChoices = activityChoices.filter(x => x !== cb.value);
  }
}

/* ============ FINISH MEETING ============ */
function finishMeeting() {
  const date = document.getElementById("meetingDate").value;
  const time = document.getElementById("meetingTime").value;
  if (!date) { showToast("Choose a date 📅"); return; }
  if (!time) { showToast("Choose a time ⏰"); return; }
  if (activityChoices.length === 0) { showToast("Choose at least one activity 😊"); return; }

  const sd = document.getElementById("summaryDate");
  const st = document.getElementById("summaryTime");
  const sa = document.getElementById("summaryActivity");
  if (sd) { const d = new Date(date+"T00:00:00"); sd.textContent = isNaN(d) ? date : d.toLocaleDateString(undefined,{day:"2-digit",month:"short",year:"numeric"}); }
  if (st) st.textContent = time;
  if (sa) sa.textContent = activityChoices.join(" • ");

  showScreen(7);
  createConfetti();

  setTimeout(() => {
    document.getElementById("friendshipLevel").textContent = "100% 🌸";
    document.getElementById("levelFill").style.width = "100%";
    saveQuiz();
    setTimeout(() => {
      createConfetti();
      showToast("🎉 You unlocked the surprise! 🎁");
      showScreen(8);
    }, 2200);
  }, 300);
}

/* ============ SURPRISE ============ */
function revealSurpriseContent(el) {
  const c = document.getElementById("surpriseContent");
  if (c) {
    c.classList.add("show");
    el.style.animation = "none";
    el.textContent = "💝";
    createConfetti();
    showToast("Surprise revealed! 🏆");
  }
}

/* ============ SPECIAL REASON ============ */
function revealSpecialReason(btn) {
  const r = btn.nextElementSibling;
  if (r.style.display === "none") {
    r.style.display = "block";
    btn.innerHTML = "💛 Hide Reason 💛";
    createConfetti();
    showToast("Between us ✨");
  } else {
    r.style.display = "none";
    btn.innerHTML = "✨ Click to Reveal Reason ✨";
  }
}

/* ============ OX GAME ============ */
let oxBoard = Array(9).fill("");
let oxGameOver = false, oxPlayerTurn = true, oxPlayerCanContinue = false, oxFiveCellsFilled = false;
const oxLines = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]];
const oxCells = document.querySelectorAll(".ox-cell");

function updateOXFilledProgress() {
  const filled = oxBoard.filter(Boolean).length;
  const count = document.getElementById("oxFilledCount");
  const msg = document.getElementById("oxFiveMessage");
  if (count) count.textContent = Math.min(filled, 5);
  oxFiveCellsFilled = filled >= 5;
  if (msg) {
    msg.classList.toggle("ready", oxFiveCellsFilled);
    msg.textContent = oxFiveCellsFilled
      ? "✨ Five spaces filled! Win the game to continue. 📅"
      : `Fill ${5-filled} more space${5-filled===1?"":"s"}. ✨`;
  }
  const b = document.getElementById("oxContinueBtn");
  if (b) b.disabled = !(oxPlayerCanContinue && oxFiveCellsFilled);
}
function oxMove(i) {
  if (oxGameOver || !oxPlayerTurn || oxBoard[i]) return;
  oxBoard[i] = "X"; renderOXBoard(); updateOXFilledProgress();
  if (getOXWinner()) { finishOXGame("player"); return; }
  if (oxBoard.every(Boolean)) { finishOXGame("draw"); return; }
  oxPlayerTurn = false; updateOXStatus("Computer is thinking...","⭕");
  setTimeout(() => {
    oxComputerMove();
    if (getOXWinner()) { finishOXGame("computer"); return; }
    if (oxBoard.every(Boolean)) { finishOXGame("draw"); return; }
    oxPlayerTurn = true; updateOXStatus("Your turn!","❌");
  }, 350);
}
function oxComputerMove() {
  const empty = [];
  for (let i = 0; i < 9; i++) if (!oxBoard[i]) empty.push(i);
  for (const i of empty) { oxBoard[i]="O"; if (getOXWinner()) { renderOXBoard(); return; } oxBoard[i]=""; }
  for (const i of empty) { oxBoard[i]="X"; if (getOXWinner()) { oxBoard[i]="O"; renderOXBoard(); return; } oxBoard[i]=""; }
  const pref = [4,0,2,6,8,1,3,5,7];
  const ch = pref.find(i => !oxBoard[i]) ?? empty[Math.floor(Math.random()*empty.length)];
  oxBoard[ch] = "O"; renderOXBoard(); updateOXFilledProgress();
}
function getOXWinner() {
  for (const [a,b,c] of oxLines) {
    if (oxBoard[a] && oxBoard[a] === oxBoard[b] && oxBoard[a] === oxBoard[c])
      return { winner: oxBoard[a], line: [a,b,c] };
  }
  return null;
}
function renderOXBoard() {
  for (let i = 0; i < oxCells.length; i++) {
    const cell = oxCells[i];
    const v = oxBoard[i];
    cell.textContent = v === "X" ? "❌" : v === "O" ? "⭕" : "";
    cell.classList.toggle("filled", Boolean(v));
    cell.classList.toggle("player", v === "X");
    cell.classList.toggle("computer", v === "O");
    cell.classList.remove("win");
  }
  const r = getOXWinner();
  if (r) r.line.forEach(i => oxCells[i]?.classList.add("win"));
}
function updateOXStatus(msg, icon) {
  document.getElementById("oxStatus").textContent = msg;
  document.getElementById("oxTurnIcon").textContent = icon;
}
function finishOXGame(result) {
  oxGameOver = true; oxPlayerTurn = false;
  const box = document.getElementById("oxResult");
  const icon = document.getElementById("oxResultIcon");
  const title = document.getElementById("oxResultTitle");
  const msg = document.getElementById("oxResultMessage");
  const btn = document.getElementById("oxContinueBtn");
  box?.classList.remove("win");

  if (result === "player") {
    oxPlayerCanContinue = true;
    icon.textContent = "🎉";
    title.textContent = "YOU WIN THIS GAME! 🥳🌸";
    msg.textContent = "Amazing! Now we can set the hangout! 📅✨";
    box?.classList.add("win");
    if (btn) btn.disabled = !oxFiveCellsFilled;
    updateOXStatus("You won! 🏆","🏆");
    createConfetti(); showToast("You win! 🎉🌸");
    setTimeout(() => {
      if (oxFiveCellsFilled) {
        createConfetti();
        showToast("Now let's plan the hangout 📅✨");
        showScreen(6);
      }
    }, 2000);
    return;
  }
  oxPlayerCanContinue = false;
  if (btn) btn.disabled = true;
  if (result === "computer") {
    icon.textContent = "⭕"; title.textContent = "Almost! Try Again 😊";
    msg.textContent = "Computer got three in a row. Play again!";
    updateOXStatus("Computer won — try again!","⭕");
  } else {
    icon.textContent = "🤝"; title.textContent = "It's a Draw!";
    msg.textContent = "No winner. Play again — you need to win!";
    updateOXStatus("Draw — play again!","🤝");
  }
}
function resetOXGame() {
  oxBoard = Array(9).fill(""); oxGameOver = false; oxPlayerTurn = true;
  oxPlayerCanContinue = false; oxFiveCellsFilled = false;
  oxCells.forEach(c => {
    c.textContent = ""; c.classList.remove("filled","player","computer","win");
  });
  document.getElementById("oxResult")?.classList.remove("win");
  document.getElementById("oxResultIcon").textContent = "✨";
  document.getElementById("oxResultTitle").textContent = "Win the game to continue 🌸";
  document.getElementById("oxResultMessage").textContent = "Get three ❌ in a row, column, or diagonal.";
  document.getElementById("oxContinueBtn").disabled = true;
  updateOXStatus("Your turn!","❌");
  updateOXFilledProgress();
}
function continueAfterOX() {
  if (!oxPlayerCanContinue) { showToast("Win the OX game first ✨"); return; }
  if (!oxFiveCellsFilled) { showToast("Fill 5 spaces first ✨"); return; }
  createConfetti(); showToast("Now let's plan the hangout 📅");
  setTimeout(() => showScreen(6), 400);
}

/* ============ SAVE QUIZ ============ */
async function saveQuiz() {
  const fd = new FormData();
  fd.append("save_quiz", "1");
  fd.append("food_category", selectedFoodCategory);

  const street = document.querySelector('input[name="street_food"]:checked');
  const homemade = document.querySelector('input[name="homemade_food"]:checked');
  const roti = document.querySelector('input[name="roti_type"]:checked');

  let dish = "";
  if (selectedFoodCategory === "street" && street) dish = street.value;
  if (selectedFoodCategory === "homemade" && homemade) dish = homemade.value;

  fd.append("food_dish", dish);
  fd.append("roti_type", roti ? roti.value : "");
  fd.append("street_food", street ? street.value : "");
  fd.append("homemade_food", homemade ? homemade.value : "");
  fd.append("custom_food", document.getElementById("customFood")?.value || "");
  fd.append("icecream_company", selectedCompany);
  fd.append("icecream_flavor", selectedFlavor);
  fd.append("comfortable", comfortableAnswer);
  fd.append("meeting_activities", activityChoices.join(", "));
  fd.append("movie_category", document.getElementById("movieCategory")?.value || "");
  fd.append("garden_location", document.getElementById("gardenLocation")?.value || "");
  fd.append("mall_choice", document.getElementById("mallChoice")?.value || "");
  fd.append("sport_choice", document.getElementById("sportChoice")?.value || "");
  fd.append("meeting_date", document.getElementById("meetingDate")?.value || "");
  fd.append("meeting_time", document.getElementById("meetingTime")?.value || "");

  try {
    const res = await fetch(window.location.pathname, {
      method: "POST",
      body: fd,
      credentials: "same-origin"
    });

    const text = await res.text();
    let json;
    try { json = JSON.parse(text); }
    catch (e) {
      console.error("Server returned non-JSON:", text);
      showToast("⚠️ Save failed — server error.");
      return;
    }

    if (json.success) {
      console.log("✅ Quiz saved! ID:", json.id);
      showToast("✅ Saved to database!");
    } else {
      console.error("❌ Save failed:", json.message);
      showToast("⚠️ " + json.message);
    }
  } catch (err) {
    console.error("❌ Network error:", err);
    showToast("⚠️ Could not reach server.");
  }
}

/* ============ CONFETTI (reduced from 80 to 30) ============ */
function createConfetti() {
  const s = ["🌸","✨","💛","🌺","🎉"];
  const frag = document.createDocumentFragment();
  for (let i = 0; i < 30; i++) {
    const p = document.createElement("div");
    p.className = "confetti";
    p.textContent = s[i % s.length];
    p.style.left = Math.random()*100 + "%";
    p.style.animationDuration = (2 + Math.random()*2) + "s";
    p.style.animationDelay = Math.random()*0.5 + "s";
    frag.appendChild(p);
    setTimeout(() => p.remove(), 4500);
  }
  document.body.appendChild(frag);
}

/* ============ TOAST ============ */
let toastTimer;
function showToast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove("show"), 1800);
}

/* ============ RESTART ============ */
function restartQuiz() { location.reload(); }

/* ============ INIT ============ */
updateProgress();
(function initDate() {
  const d = document.getElementById("meetingDate");
  if (!d) return;
  const t = new Date();
  d.min = `${t.getFullYear()}-${String(t.getMonth()+1).padStart(2,"0")}-${String(t.getDate()).padStart(2,"0")}`;
})();
(function initTime() {
  const sel = document.getElementById("meetingTime");
  if (!sel) return;
  const frag = document.createDocumentFragment();
  for (let h = 8; h <= 22; h++) {
    for (let m = 0; m < 60; m += 30) {
      const period = h >= 12 ? "PM" : "AM";
      const dh = h > 12 ? h-12 : (h === 0 ? 12 : h);
      const dm = m === 0 ? "00" : "30";
      const opt = document.createElement("option");
      opt.value = `${String(h).padStart(2,"0")}:${String(m).padStart(2,"0")}`;
      opt.textContent = `${dh}:${dm} ${period}`;
      frag.appendChild(opt);
    }
  }
  sel.appendChild(frag);
})();
</script>

</body>
</html>